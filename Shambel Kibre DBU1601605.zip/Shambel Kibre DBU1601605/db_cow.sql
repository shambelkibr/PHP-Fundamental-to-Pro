-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 19, 2026 at 10:57 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_cow`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_disease`
--

CREATE TABLE `tbl_disease` (
  `Cow_id` int(10) UNSIGNED NOT NULL,
  `D_Name` varchar(100) NOT NULL,
  `Symptoms` varchar(255) NOT NULL,
  `Dignosis_Date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `Treatment` varchar(255) NOT NULL,
  `Store_DATE` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_disease`
--

INSERT INTO `tbl_disease` (`Cow_id`, `D_Name`, `Symptoms`, `Dignosis_Date`, `Treatment`, `Store_DATE`) VALUES
(2, 'Pneumonia', 'Swollen udder, milk discoloration, pain during milking', '2026-05-23 08:15:00', 'Antibiotic injection for 5 days and proper udder hygiene', '2026-05-30 08:15:00'),
(101, 'Bovine Tuberculosis', 'cough, weight loss, weak appetite, fever', '2026-05-28 07:55:00', 'Antibiotics, isolation, long-term monitoring', '2026-05-14 07:55:00'),
(102, 'Bovine Tuberculosis', 'Difficulty breathing, nasal discharge, fever, loss of appetite', '2026-05-28 07:55:00', ' Antibiotic injection, rest, clean environment', '2026-05-14 07:55:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_disease`
--
ALTER TABLE `tbl_disease`
  ADD PRIMARY KEY (`Cow_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_disease`
--
ALTER TABLE `tbl_disease`
  MODIFY `Cow_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=201;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
